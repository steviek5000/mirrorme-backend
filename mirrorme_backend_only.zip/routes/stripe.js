const express = require('express');
const router = express.Router();
const Stripe = require('stripe');
const db = require('../utils/firebase');

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

// POST /api/stripe/connect
router.post('/connect', async (req, res) => {
  const { userId } = req.body;

  try {
    const account = await stripe.accounts.create({ type: 'express' });

    const link = await stripe.accountLinks.create({
      account: account.id,
      refresh_url: 'https://mirrorme.ai/creator/refresh',
      return_url: 'https://mirrorme.ai/creator/return',
      type: 'account_onboarding',
    });

    // Save account ID to Firestore
    await db.collection('creators').doc(userId).update({
      stripeAccountId: account.id,
      stripeOnboarded: false
    });

    res.json({ url: link.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Stripe connect failed.' });
  }
});

// POST /api/stripe/checkout
router.post('/checkout', async (req, res) => {
  const { viewerEmail, creatorId } = req.body;

  try {
    const doc = await db.collection('creators').doc(creatorId).get();
    if (!doc.exists) return res.status(404).json({ error: 'Creator not found' });

    const { stripeAccountId, price } = doc.data();

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: 'usd',
          product_data: {
            name: "Access MirrorMe Twin",
          },
          unit_amount: Math.round((price || 500) * 100),
        },
        quantity: 1,
      }],
      mode: 'payment',
      customer_email: viewerEmail,
      success_url: 'https://mirrorme.ai/success',
      cancel_url: 'https://mirrorme.ai/cancel',
      payment_intent_data: {
        application_fee_amount: 100, // $1 fee
        transfer_data: {
          destination: stripeAccountId,
        },
      },
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Checkout failed.' });
  }
});

module.exports = router;
