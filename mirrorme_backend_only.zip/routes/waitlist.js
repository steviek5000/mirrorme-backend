const express = require('express');
const router = express.Router();
const db = require('../utils/firebase');
const crypto = require('crypto');

// POST /api/waitlist
router.post('/', async (req, res) => {
  const { email, ref } = req.body;
  if (!email) return res.status(400).json({ error: 'Missing email' });

  const refCode = 'ref-' + crypto.randomBytes(3).toString('hex');

  try {
    await db.collection('waitlist').doc(email).set({
      email,
      myRefCode: refCode,
      referrerCode: ref || null,
      timestamp: new Date().toISOString()
    });

    // Count referral
    if (ref) {
      const refDoc = db.collection('referrals').doc(ref);
      await refDoc.set({ count: 1 }, { merge: true });
      await refDoc.update({ count: db.FieldValue.increment(1) });
    }

    res.json({ refCode });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to save to waitlist.' });
  }
});

module.exports = router;
